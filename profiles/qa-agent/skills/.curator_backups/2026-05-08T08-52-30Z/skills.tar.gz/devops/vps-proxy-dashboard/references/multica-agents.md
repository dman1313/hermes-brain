# Multica Agents Dashboard Integration

Full Python/Flask code to embed a live Multica agent roster in the VPS proxy dashboard.

## Backend: `multica_agents()` function

Add to `dashboard.py`:

```python
import subprocess

MULTICA_BIN = "/usr/local/bin/multica"

def multica_agents():
    """Fetch Multica agent list. Cached per-request via the calling route."""
    try:
        result = subprocess.run(
            ["sudo", "-u", "ubuntu", MULTICA_BIN, "agent", "list", "--output", "json"],
            capture_output=True, text=True, timeout=15
        )
        if result.returncode == 0:
            agents = json.loads(result.stdout)
            status_order = {"active": 0, "idle": 1, "offline": 2, "error": 3}
            agents.sort(key=lambda a: status_order.get(a.get("status", "unknown"), 99))
            counts = {"active": 0, "idle": 0, "offline": 0, "total": len(agents)}
            for a in agents:
                s = a.get("status", "unknown")
                if s in counts:
                    counts[s] += 1
            return {"agents": agents, "counts": counts, "error": None}
        return {"agents": [], "counts": {}, "error": f"multica exit {result.returncode}: {result.stderr[:200]}"}
    except FileNotFoundError:
        return {"agents": [], "counts": {}, "error": f"multica binary not found at {MULTICA_BIN}"}
    except subprocess.TimeoutExpired:
        return {"agents": [], "counts": {}, "error": "multica command timed out"}
    except json.JSONDecodeError as e:
        return {"agents": [], "counts": {}, "error": f"JSON parse error: {e}"}
    except Exception as e:
        return {"agents": [], "counts": {}, "error": str(e)}
```

## Status class helper

```python
def agent_status_class(status):
    if status == "active":
        return "status-good"
    elif status == "offline":
        return "status-bad"
    elif status == "error":
        return "status-warn"
    return ""  # idle — default color
```

## CSS (add to existing `<style>` block)

```css
.agent-summary { display:flex; gap:1.5rem; margin-bottom:1rem; flex-wrap:wrap; }
.agent-summary span { font-size:.9rem; color:#8b949e; }
.agent-summary strong { color:#c9d1d9; }
.agent-row { padding:.6rem 0; border-bottom:1px solid #21262d; }
.agent-row:last-child { border-bottom:none; }
.agent-left { display:flex; align-items:center; gap:.5rem; flex-wrap:wrap; }
.agent-status { font-size:.85rem; }
.agent-meta { font-size:.75rem; color:#484f58; margin-left:.25rem; }
.agent-desc { font-size:.8rem; color:#8b949e; margin-top:.25rem; margin-left:1.2rem; }
```

## HTML card (in `index()` return)

```python
agent_data = multica_agents()
agents = agent_data["agents"]
agent_counts = agent_data["counts"]
agent_error = agent_data["error"]

# Build agent rows
agent_rows = ""
if agent_error:
    agent_rows = f'<p style="color:#f85149">Error fetching agents: {agent_error}</p>'
elif not agents:
    agent_rows = '<p style="color:#8b949e">No agents found.</p>'
else:
    for a in agents:
        name = a.get("name", "?")
        st = a.get("status", "?")
        desc = a.get("description", "")[:120]
        updated = a.get("updated_at", "")[:10] if a.get("updated_at") else "—"
        runtime = a.get("runtime_mode", "?")
        cls = agent_status_class(st)
        agent_rows += (
            f'<div class="agent-row">'
            f'<div class="agent-left">'
            f'<span class="agent-status {cls}">&#9679;</span> '
            f'<strong>{name}</strong>'
            f'<span class="agent-meta"> · {st} · {runtime} · updated {updated}</span>'
            f'</div>'
            f'<div class="agent-desc">{desc or "—"}</div>'
            f'</div>'
        )
```

Card HTML:

```html
<div class="card">
<h2>Multica Agents ({agent_counts.get("total", 0)})</h2>
<div class="agent-summary">
  <span><span class="status-good">&#9679;</span> <strong>{agent_counts.get("active", 0)}</strong> active</span> |
  <span><span>&#9679;</span> <strong>{agent_counts.get("idle", 0)}</strong> idle</span> |
  <span><span class="status-bad">&#9679;</span> <strong>{agent_counts.get("offline", 0)}</strong> offline</span>
</div>
{agent_rows}
</div>
```

## API endpoint

```python
@app.route("/api/agents")
def api_agents():
    return jsonify(multica_agents())
```

## Restart

```bash
sudo systemctl restart proxy-dashboard
```

## Why `sudo -u ubuntu`?

The proxy-dashboard systemd service runs as `root`, but the Multica CLI reads its config and auth token from `/home/ubuntu/.multica/config.json`. Root's home is `/root/`, so `multica agent list` fails with "No server configured." The fix is `sudo -u ubuntu multica ...` — run the command as the ubuntu user so it finds the correct config.

# Hermes State Backup to Google Drive

Daily automated backup of critical Hermes agent state to Google Drive.

## Script

`/home/ubuntu/scripts/hermes-backup.py` — creates a timestamped tarball and uploads via `google_api.py drive upload`.

**Included:** `skills/`, `cron/`, `SOUL.md`, `config.yaml`, `gateway_state.json`, `channel_directory.json`, `tasks.json`, `workspace-sessions.json`, `processes.json`

**Excluded:** `sessions/` (432M+ of chat logs), OAuth tokens, model caches, `auth.json` — all regeneratable or sensitive.

## Cron

Job: `hermes-gdrive-backup` — runs daily at 3 AM local, keeps last 7 backups via `drive delete --keep 7`.

## Drive Upload Mechanics

The `google_api.py drive upload` command upserts by name: if a file with the same name exists, it replaces it. If not, it creates a new one. Rotation is handled by `drive delete <pattern> --keep N` which trashes older matching files beyond the retention count.

## Restoration

To restore from a backup:
1. Download the tarball from Google Drive (use `drive search "hermes-backup-"` to find the latest)
2. Extract into `$HOME/.hermes/`: `tar xzf hermes-backup-*.tar.gz -C $HOME/.hermes/`
3. Restart Hermes

---
name: hermes-model-roster
category: hermes
description: Display comprehensive LLM roster from Hermes system configuration and models cache
tags: [hermes, models, inventory, diagnostic]
triggers:
  - "show me your llm roster"
  - "what models do you have"
  - "list available models"
  - "hermes model inventory"
---

# Hermes Model Roster

This skill provides a comprehensive overview of all LLM models and providers available in your Hermes system.

## Prerequisites

- Hermes Agent installed and configured
- Access to Hermes configuration files
- JSON parsing capability (jq recommended)

## Procedure

1. **Check current configuration**
   - Read Hermes configuration file to understand:
     - Default model and provider
     - Current model in use
     - Smart model routing settings
     - Delegation model configuration

2. **Parse models cache**
   - Extract information from Hermes models cache file:
     - List all available providers
     - Show key models from each provider
     - Handle hyphenated provider names with proper JSON quoting

3. **Organize by provider**
   Present information in structured format:
   - Primary configuration first
   - Major providers (OpenAI, Anthropic, ZAI, etc.)
   - Specialized providers (Kimi, OpenRouter, etc.)
   - Other available providers

4. **Include routing configuration**
   Show model routing settings:
   - Delegation model
   - Smart routing cheap model
   - Auxiliary models for specific tasks

## Key Findings Structure

Present the roster in this format:

```
## Primary Configuration
- Default Model: [model]
- Current Model: [model]
- Smart Model Routing: [enabled/disabled]

## Available Providers
### 1. [Provider Name]
Key models:
- [Model Name] ([Model ID])
- [Model Name] ([Model ID])
- ...

### 2. [Provider Name]
...

## Model Routing Configuration
- Delegation Model: [model]
- Cheap Model: [model]
- Auxiliary Models: [list]
```

## Notes

- The models cache typically contains 100+ models across 40+ providers
- Smart routing automatically selects appropriate models based on task complexity
- Provider availability depends on API keys and authentication
- Some providers require specific environment variables to be configured

## Troubleshooting

If encountering JSON parsing errors with hyphenated provider names:
- Use proper quoting around keys containing hyphens
- This is required because some parsers treat hyphens as subtraction operators

If models cache is missing or empty:
- Run `hermes model` command to refresh the cache
- Check internet connectivity for provider API access
- Verify API keys are properly configured in your environment

## Common Providers Found

- **OpenAI/OpenAI Codex**: GPT-5 series, GPT-4o, o1/o3/o4 series
- **Anthropic**: Claude Sonnet, Opus, Haiku series
- **ZAI**: GLM series (4.5, 4.6, 4.7, 5, 5.1)
- **Kimi For Coding**: Kimi K2 series, specialized for coding tasks
- **OpenRouter**: DeepSeek, LFM, Trinity, FLUX models and many others
- **Others**: 302.AI, Google/Vertex, MiniMax, Perplexity, etc.
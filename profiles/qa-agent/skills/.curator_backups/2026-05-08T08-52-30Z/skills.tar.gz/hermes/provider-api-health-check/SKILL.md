---
name: provider-api-health-check
category: hermes
description: Systematically test LLM provider APIs to determine which models actually work. Two-phase probe of /models endpoint then chat completions.
tags: [hermes, diagnostics, models, providers, api-testing]
triggers:
  - "test all models"
  - "api check for models"
  - "which models work"
  - "validate provider APIs"
  - "check model availability"
  - "remove broken models"
  - "verify API keys"
---

# Provider API Health Check

Systematic validation of LLM provider APIs to determine which providers and models are actually functional. Uses a two-phase approach: first probes the `/models` endpoint for provider reachability, then tests actual chat completions to catch models that are listed but non-functional.

## Why This Matters

The models cache (`models_dev_cache.json`) lists models from 40+ providers, but:
- Many providers have no valid API keys configured
- The `/models` endpoint returns models that can't actually serve chat completions (e.g., OpenRouter lists OpenAI gpt-5.x models that all return 400)
- Credential pool status flags (e.g., `exhausted`) can be stale -- keys marked exhausted may actually work
- Base URLs change, endpoints get deprecated, API versions drift

## Prerequisites

- Access to `~/.hermes/auth.json` for credential pools
- Access to `~/.hermes/config.yaml` for provider configurations
- `curl` installed
- Python with `json` standard library
- Network connectivity to provider API endpoints

## Procedure

### Phase 1: Inventory Credentials

First, map out what credentials exist:

```python
from hermes_tools import terminal
import json

result = terminal("cat ~/.hermes/auth.json")
auth = json.loads(result["output"])

pool = auth.get("credential_pool", {})
for name, creds in pool.items():
    for c in creds:
        tok = c.get("access_token", "")
        label = c.get("label", "")
        src = c.get("source", "")
        bu = c.get("base_url", "")
        status = c.get("last_status", "")
        print(f"{name}/{label}: token_len={len(tok)} src={src} base={bu} status={status}")
```

**Key insight:** Do not rely on env vars for API keys. Hermes loads keys from auth.json credential pool, which includes env, manual, device_code sources.

### Phase 2: Extract Provider Config

```python
result = terminal("cat ~/.hermes/config.yaml")
import re
providers_match = re.search(r'providers:\n(.*?)(?=\n\w+:)', result["output"], re.DOTALL)
```

### Phase 3: Test /models Endpoint

```python
import subprocess, json

def test_provider(base_url, api_key, name):
    headers = ["-H", f"Authorization: Bearer {api_key}"]
    if "anthropic" in name.lower():
        headers = ["-H", "x-api-key: " + api_key, "-H", "anthropic-version: 2023-06-01"]
    
    r = subprocess.run(
        ["curl", "-s", "-w", "\n%{http_code}"] + headers + [f"{base_url}/models"],
        capture_output=True, text=True, timeout=10
    )
    lines = r.stdout.strip().split("\n")
    http_code = lines[-1]
    body = "\n".join(lines[:-1])
    
    if "200" <= http_code < "300":
        try:
            data = json.loads(body)
            models = data.get("data", [])
            model_ids = [m["id"] for m in models]
            return ("OK", model_ids)
        except:
            return ("OK", [])
    else:
        return (f"FAIL_{http_code}", [])
```

Auth header reference:
| Provider | Auth Method |
|----------|-------------|
| OpenAI-compatible | Bearer token |
| Anthropic | x-api-key + anthropic-version |
| OpenAI Codex | OAuth device_code |

### Phase 4: Test Chat Completions (The Critical Check)

```python
import subprocess, json

def test_chat(base_url, api_key, model, timeout=15):
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"}
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": "Reply with just the word OK"}],
        "max_tokens": 10
    })
    
    try:
        r = subprocess.run(
            ["curl", "-s", "-w", "\n%{http_code}", "--max-time", str(timeout)] +
            [f"-H{k}:{v}" for k, v in headers.items()] +
            ["-d", payload, f"{base_url}/chat/completions"],
            capture_output=True, text=True, timeout=timeout+5
        )
        lines = r.stdout.strip().split("\n")
        hc = lines[-1]
        
        if "200" <= hc < "300":
            try:
                j = json.loads("\n".join(lines[:-1]))
                content = j.get("choices", [{}])[0].get("message", {}).get("content", "")
                return "OK", content[:50]
            except:
                return "OK", ""
        elif hc in ("401", "403"):
            return "AUTH_FAIL", ""
        elif hc == "429":
            return "RATE_LIMITED", ""
        else:
            body = "\n".join(lines[:-1])
            return f"HTTP_{hc}", body[:80]
    except subprocess.TimeoutExpired:
        return "TIMEOUT", ""
    except Exception as e:
        return "ERROR", str(e)[:50]
```

### Phase 5: Testing Priority

Test in this order:
1. Active providers in config.yaml (default, fallback, delegation models)
2. Credential-pool providers with keys
3. Cached providers from models_dev_cache.json (only if comprehensive)

## Common Pitfalls

### 1. OpenRouter Lists Models It Cannot Serve
OpenRouter returns 353+ models from /models, but OpenAI gpt-5.x models (gpt-5.5, 5.4, 5.2, 5.1, o3, o4-mini, etc.) all return HTTP 400 on chat completions. OpenRouter lacks the direct OpenAI API key needed to route these.

### 2. Credential Pool Status Is Misleading
- `status=exhausted` does not guarantee the key is dead (ZAI keys worked despite exhausted status)
- `status=ok` does not guarantee the key works today (Anthropic showed ok but returned 401)
- Always verify with actual API calls, never trust cached status

### 3. Timeout Sensitivity
| Provider | Recommended Timeout |
|----------|-------------------|
| DeepSeek | 10-15s |
| Xiaomi (both endpoints) | 10-15s |
| OpenRouter | 15-20s |
| Z.AI | 20-30s |
| Anthropic | 15s |
| Kimi | 10s |

### 4. Xiaomi Token Plan Recovery
The `token-plan-ams.xiaomimimo.com/v1` endpoint previously returned 502 errors but recovered. Retest periodically for recovered endpoints.

### 5. OpenRouter 402 Does Not Mean Dead Provider
OpenRouter returns HTTP 402 "This request requires more credits" when the remaining balance is insufficient for the requested `max_tokens`. The provider is alive — the request just needs a smaller `max_tokens` (try 10 for health checks). The system's remaining balance and monthly limit are available via `GET /api/v1/auth/key`. Do NOT mark OpenRouter as failed based on 402 alone.

### 6. Codex OAuth Tokens Expire (~5 Days)
OpenAI Codex uses OAuth device flow tokens that expire after a few days. If the `openai-codex` credential pool returns 403, the access token has expired. A `refresh_token` is stored but the Codex CLI (v0.118+) also changed its expected auth format — `codex whoami` may fail with `missing field id_token`. Re-authentication requires running the device flow again. Until then, Codex as a Hermes provider is dead, but the credential pool entry can stay (harmless).

### 7. API Keys Are Redacted — Use Hermes CLI Instead
Hermes redacts secrets when reading `auth.json` or `.env` via `read_file` or `terminal("cat ...")`. You **cannot** extract raw API keys to use with raw `curl` calls in Phase 3/4. The Python-code approach in those phases is broken in the Hermes context.

**For connectivity testing (Phase 3 replacement):** `hermes doctor` tests /models reachability for all configured providers:
```
hermes doctor 2>&1
```
This reports ✓/✗/⚠ for OpenRouter, Anthropic, Z.AI/GLM, Kimi, DeepSeek, MiniMax, etc.

**For chat completion testing (Phase 4 replacement):** Use `hermes -z` (one-shot mode) to test specific models through Hermes' own routing:
```
timeout 30 hermes -z "Reply with exactly OK and nothing else." --provider deepseek -m deepseek-v4-pro 2>&1
timeout 30 hermes -z "Reply with exactly OK and nothing else." --provider xiaomi -m mimo-v2.5-pro 2>&1
timeout 30 hermes -z "Reply with exactly OK and nothing else." --provider zai -m glm-5.1 2>&1
```

This tests the full provider routing, credential pool, and chat completion pipeline — more accurate than raw curl anyway, and doesn't require reading secrets.

## Result Categorization

Three categories for providers:
- **working**: /models responds AND chat completions pass
- **partial**: /models responds but some/all chat completions fail
- **failed**: /models endpoint unreachable, no key, or auth failure

## Reporting Format

```
## Provider Health Summary

### Working Providers
- Provider: N models -- [model list]

### Partial / Inconsistent
- Provider: N listed, M chat failures -- [details]

### Failed Providers
- Provider: Reason (404/401/no key/rate limited)
```

### 8. deepseek-chat and google/gemini-2.5-flash Silently Fail
These models may produce zero assistant responses on simple prompts (tested: "Reply with exactly OK"). No error message, no HTTP failure — just empty output. If testing model availability, check for non-empty responses. Use deepseek-v4-pro or mimo-v2.5-pro as the reference model for health checks. (Observed: 3 consecutive failures on deepseek-chat, 1 on gemini-2.5-flash, Apr 30 2026.)

## Verification After Cleanup

After removing failed providers or models:
1. Rerun Phase 4 on remaining providers
2. Verify the default model still works for completions
3. Confirm fallback providers are functional

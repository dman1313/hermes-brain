# Xiaomi Token Plan Recovery — Session 2026-05-23

## Problem
Xiaomi provider returning 401 "Invalid API Key" on all requests. Model had been switched from mimo-v2.5-pro to deepseek-v4-pro.

## Diagnosis Chain

1. `hermes status` — showed Xiaomi MiMo as active provider, but Xiaomi not in API Keys section (expected — Xiaomi only shows in provider line)
2. `hermes doctor` — no Xiaomi-specific health check
3. Raw curl to `https://token-plan-ams.xiaomimimo.com/v1/models` — returned 401 "Invalid API Key"
4. Checked `auth.json` credential pool: `xiaomi` pool entry had `last_status: exhausted`, key `tp-eus7o7y...ty92`
5. User provided new token: `tp-e7pw6b8tsdcvm6k6twcnu6egf9072rlpbmpmniddqsy3wuyn`
6. Updated both `.env` and `auth.json` with new token
7. Retested — still 401

## Root Cause
The Xiaomi token plan requires an Anthropic API key to be configured on their portal. The token alone is insufficient. Even a fresh, valid token returns 401 if the upstream Anthropic key is missing or expired on the Xiaomi side.

**Important:** The portal URL `https://token-plan-ams.xiaomimimo.com/anthropic` returns 404 both with and without the token in Authorization headers. The root path `/` also returns 404. Only `/v1/models` and `/v1/chat/completions` are reachable (returning 401 when unconfigured). The management portal is likely at a different host or requires browser-based authentication that cannot be replicated via curl. The user must use a browser to configure the upstream key.

## Resolution Path
1. Update token in `.env` and `auth.json` (done)
2. User must visit Xiaomi token plan management dashboard in browser
3. Configure/update Anthropic API key on the portal
4. Retest after upstream key is set

## Key Files Modified
- `~/.hermes/.env` — XIAOMI_API_KEY updated
- `~/.hermes/auth.json` — both `xiaomi` and `custom:xiaomi` credential pool entries cleared of exhausted status, new access_token set

## Related Env Vars
- XIAOMI_API_KEY=tp-e7pw6b8tsdcvm6k6twcnu6egf9072rlpbmpmniddqsy3wuyn
- XIAOMI_BASE_URL=https://token-plan-ams.xiaomimimo.com/v1
- XIAOMI_ANTHROPIC_BASE_URL=https://token-plan-ams.xiaomimimo.com/anthropic

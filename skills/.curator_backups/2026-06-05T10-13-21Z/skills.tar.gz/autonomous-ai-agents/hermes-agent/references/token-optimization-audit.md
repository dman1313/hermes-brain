# Token Optimization Audit

Systematic method for auditing and reducing per-turn token overhead in Hermes Agent.

## Per-Turn Overhead Estimation

Every turn burns tokens before any user message. Estimate these components:

| Component | How to measure | Typical range |
|-----------|---------------|---------------|
| SOUL.md | `wc -c ~/SOUL.md` (or `~/.hermes/SOUL.md`) | 1-11KB (~300-3000 tokens) |
| System prompt (hermes core) | Hardcoded, ~8KB | ~2,500 tokens |
| AGENTS.md context injection | `wc -c AGENTS.md` | 1-6KB (~300-2000 tokens) |
| MEMORY.md | `wc -c ~/.hermes/MEMORY.md` | 0-4KB (~0-1200 tokens) |
| USER.md | `wc -c ~/.hermes/USER.md` | 0-2.5KB (~0-750 tokens) |
| Tool schemas | Count tools × avg schema size | 5,000-25,000 tokens |
| Plugin toolsets | Depends on plugins | 1,000-5,000 tokens |

**Rule of thumb:** If baseline overhead exceeds 15K tokens, you're leaving optimization on the table.

## The 5 Biggest Wins (Ranked)

### 1. Trim SOUL.md
SOUL.md injects every turn. Reference material (agent routing tables, conflict resolution rules, orchestration patterns) should move to a skill that loads on demand. Target: <3KB.

### 2. Disable Unused Toolsets
`disabled_toolsets: []` in config means everything loads. Each MCP server injects its full schema. Browser alone is ~10 tools. Disable what you don't use daily; delegate when needed.

```yaml
# In config.yaml
agent:
  disabled_toolsets:
    - browser
    - vision
    - image_gen
```

Add delegation instructions to SOUL.md:
```markdown
## Browser delegation
When you need browser interaction, delegate via delegate_task(toolsets=['browser'])
```

**Constraint:** delegate_task children cannot re-enable toolsets the parent has disabled (intersection check). Use separate profiles for MCP-heavy tasks.

### 3. Default Model Selection
Don't use your most expensive model for trivial queries. Options:
- Set default to cheaper model, escalate per-task
- Use Manifest (open-source model router) for automatic routing
- At minimum, set delegation model to cheapest capable model

### 4. Reasoning Effort
`reasoning_effort: high` on everything burns extra chain-of-thought tokens. Default to `medium`, escalate per-task.

```yaml
agent:
  reasoning_effort: medium
delegation:
  reasoning_effort: medium
```

### 5. System Prompt Weight
AGENTS.md, SOUL.md, MEMORY.md, and skills all inject every turn. Periodic review to trim these saves tokens on every single call.

## Tool Schema Token Estimates

| Toolset | Tools | ~Tokens/turn |
|---------|-------|-------------|
| Browser | ~10-12 | 1,500-2,000 |
| MCP (varies by server) | 5-60+ | 2,000-15,000 |
| Built-in (terminal, file, web, etc.) | ~20-30 | 3,000-5,000 |
| Plugins | varies | 1,000-3,000 |

## Quick Audit Commands

```bash
# SOUL.md size
wc -c ~/SOUL.md ~/.hermes/SOUL.md 2>/dev/null

# MEMORY.md and USER.md size
wc -c ~/.hermes/MEMORY.md ~/.hermes/USER.md 2>/dev/null

# Count skills
ls ~/.hermes/skills/ | wc -l

# Check disabled toolsets
grep -A5 'disabled_toolsets' ~/.hermes/config.yaml

# Check delegation model
grep -A5 'delegation:' ~/.hermes/config.yaml

# Check reasoning effort
grep 'reasoning_effort' ~/.hermes/config.yaml

# Count MCP tools (approximate)
grep -c 'name:' ~/.hermes/config.yaml  # rough
```

## Cost Optimization Matrix

| Strategy | Savings | Effort |
|----------|---------|--------|
| Trim SOUL.md to <3KB | ~2,500 tokens/turn | Edit file, 20 min |
| Disable unused toolsets | ~5,000-10,000 tokens/turn | Config change, 5 min |
| Lower reasoning effort to medium | ~1,000-2,000 tokens/turn | Config change, 1 min |
| Switch delegation to cheap model | Varies by usage | Config change, 1 min |
| CONTEXT.md for projects | Replaces 10-15 tool calls | Write file, 20 min |
| Manifest model router | 80%+ on routing | Docker install, 10 min |

## Reddit Community Reference

The r/hermesagent community has documented a layered approach:
1. Manifest model router (complexity-based routing to cheapest capable model)
2. Delegation discipline (50-line threshold for subagent dispatch)
3. Delegate-first tool access (disable heavy toolsets, delegate when needed)
4. Static knowledge (CONTEXT.md, Obsidian vault for project docs)
5. Self-audit cron job (detect sessions with excessive direct tool use)

Source: https://www.reddit.com/r/hermesagent/
